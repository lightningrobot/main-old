# main
Lightning Robot Main code.
